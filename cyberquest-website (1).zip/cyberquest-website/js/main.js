/* ============================================================
   CyberQuest Website — main.js
   Interacciones, formulario, scroll effects
   ============================================================ */

(function () {
  'use strict';

  // ── Header scroll state ─────────────────────────────────
  const header = document.querySelector('.site-header');
  function onScroll() {
    if (window.scrollY > 20) header.classList.add('scrolled');
    else header.classList.remove('scrolled');
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // ── Mobile menu toggle ──────────────────────────────────
  const menuBtn = document.querySelector('.btn-mobile-menu');
  const navMain = document.querySelector('.nav-main');
  if (menuBtn && navMain) {
    menuBtn.addEventListener('click', () => {
      navMain.classList.toggle('open');
    });
    navMain.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => navMain.classList.remove('open'));
    });
  }

  // ── Scroll reveal animations ────────────────────────────
  const revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealEls.length) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    revealEls.forEach(el => io.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('visible'));
  }

  // ── Contact form ────────────────────────────────────────
  const form = document.getElementById('contact-form');
  const formSuccess = document.getElementById('form-success');
  const caseRef = document.getElementById('case-ref');

  if (form) {
    const fields = {
      name: form.querySelector('[name="name"]'),
      email: form.querySelector('[name="email"]'),
      phone: form.querySelector('[name="phone"]'),
      service: form.querySelector('[name="service"]'),
      message: form.querySelector('[name="message"]'),
    };

    function showError(field, msg) {
      field.classList.add('error');
      let errEl = field.parentElement.querySelector('.form-error');
      if (!errEl) {
        errEl = document.createElement('div');
        errEl.className = 'form-error';
        field.parentElement.appendChild(errEl);
      }
      errEl.textContent = msg;
    }

    function clearError(field) {
      field.classList.remove('error');
      const errEl = field.parentElement.querySelector('.form-error');
      if (errEl) errEl.remove();
    }

    Object.values(fields).forEach(f => {
      if (f) f.addEventListener('input', () => clearError(f));
      if (f && f.tagName === 'SELECT') f.addEventListener('change', () => clearError(f));
    });

    form.addEventListener('submit', (e) => {
      e.preventDefault();

      let hasError = false;
      if (!fields.name.value.trim()) { showError(fields.name, 'Nombre requerido'); hasError = true; }
      if (!fields.email.value.includes('@') || !fields.email.value.includes('.')) { showError(fields.email, 'Correo inválido'); hasError = true; }
      if (!fields.service.value) { showError(fields.service, 'Seleccione un servicio'); hasError = true; }
      if (fields.message.value.trim().length < 10) { showError(fields.message, 'Describa su caso (mín. 10 caracteres)'); hasError = true; }

      if (hasError) return;

      // Generate pseudo case reference
      const ref = Math.random().toString(36).slice(2, 8).toUpperCase();
      if (caseRef) caseRef.textContent = 'CASE_REF: ' + ref;

      // Build WhatsApp message
      const waMessage = encodeURIComponent(
        `Hola CyberQuest, solicito consulta confidencial.\n\n` +
        `Nombre: ${fields.name.value}\n` +
        `Correo: ${fields.email.value}\n` +
        (fields.phone.value ? `Teléfono: ${fields.phone.value}\n` : '') +
        `Servicio: ${fields.service.value}\n\n` +
        `Caso: ${fields.message.value}\n\n` +
        `Ref: ${ref}`
      );

      // Hide form, show success
      form.style.display = 'none';
      formSuccess.style.display = 'block';

      // Open WhatsApp in a new tab after 600ms so user sees the success state
      setTimeout(() => {
        window.open(`https://wa.me/1862812098?text=${waMessage}`, '_blank');
      }, 600);
    });

    // Reset form button in success view
    const resetBtn = document.getElementById('form-reset');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        form.reset();
        form.style.display = 'flex';
        formSuccess.style.display = 'none';
        Object.values(fields).forEach(f => f && clearError(f));
      });
    }
  }

  // ── Stats counter animation ─────────────────────────────
  const statValues = document.querySelectorAll('.stat-value[data-target]');
  if ('IntersectionObserver' in window && statValues.length) {
    const statIO = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        const el = entry.target;
        const target = parseFloat(el.dataset.target);
        const suffix = el.dataset.suffix || '';
        const duration = 1400;
        const start = performance.now();
        function tick(now) {
          const p = Math.min((now - start) / duration, 1);
          const eased = 1 - Math.pow(1 - p, 3);
          const val = target * eased;
          el.textContent = (Number.isInteger(target) ? Math.round(val) : val.toFixed(1)) + suffix;
          if (p < 1) requestAnimationFrame(tick);
          else el.textContent = (Number.isInteger(target) ? target : target.toFixed(1)) + suffix;
        }
        requestAnimationFrame(tick);
        statIO.unobserve(el);
      });
    }, { threshold: 0.5 });
    statValues.forEach(el => statIO.observe(el));
  }

  // ── Current year in footer ──────────────────────────────
  const yearEl = document.getElementById('current-year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

})();
